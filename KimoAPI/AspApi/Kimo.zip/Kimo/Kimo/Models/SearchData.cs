﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Kimo.Models
{
    public class SearchData
    {
        public DateTime startdate { get; set; }
        public DateTime enddate { get; set; }
    }
}